import React from "react";
import Button from "react-bootstrap/Button";
import Card from "react-bootstrap/Card";
import ButtonGroup from "react-bootstrap/ButtonGroup";
import { Link } from "react-router-dom";
import './Players.css'
const Player = ({ player, view }) => {
  const { id, name, image, category, country } = player;
  // console.log(props);
  const buttons = () => {
    if (view) {
      return (
        <ButtonGroup aria-label="Basic example">
          <Button  variant="secondary">EDIT</Button>
          <Button variant="secondary">DELETE</Button>
        </ButtonGroup>
      );
    } else {
      return (
        <Button variant="danger">
          <Link to={`/players/${id}`}>VIEW</Link>
        </Button>
      );
    }
  };
  return (
    <div>
      <Card style={{ width: "16rem" }}>
        <Card.Img variant="top" src={image} />
        <Card.Body>
          <Card.Title>Player No {id}</Card.Title>
          <Card.Text>{name}</Card.Text>
          <Card.Text>{category}</Card.Text>
          <Card.Text>{country}</Card.Text>
          {buttons()}
        </Card.Body>
      </Card>
    </div>
  );
};

export default Player;
