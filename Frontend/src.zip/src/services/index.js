import axios from 'axios';

const base = "http://localhost:3006";

export function getPlayers(){
    return axios.get(`${base}/players`);
}

export function getPlayers2(id){
    return axios.get(`${base}/players/${id}`);

}