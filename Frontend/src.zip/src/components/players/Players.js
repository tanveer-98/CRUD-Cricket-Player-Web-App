import React, { useEffect, useState } from "react";
import {lazy , Suspense} from 'react'
import "./Players.css";
import { getPlayers } from "../../services/index";

const Player = lazy(()=>import("./Player"));

const Players = () => {
  const [data, setData] = useState([]);
  useEffect(() => {
    getPlayers().then((res) => {setData(res.data);
    console.log(res);
    });
  
  }, []);

  console.log(data);

  return (
    <div
      style={{ display: "flex", flexDirection: "row" ,flexWrap:'wrap' }}
      className="container"
    >
      <Suspense fallback ={<h1> Still Loading ... </h1>}>
      {data && data.map((ele) => <Player player={ele} />)}
  
      </Suspense>
       </div>
  );
};

export default Players;
